package com.example.week4z_160919005_lukitaiswara.model

data class Student(
    val id:String?,
    val name:String?,
    val bod:String?,
    val phone:String?,
    val photoUrl:String?

)

