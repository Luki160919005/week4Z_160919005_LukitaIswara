package com.example.week4z_160919005_lukitaiswara.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.week4z_160919005_lukitaiswara.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}